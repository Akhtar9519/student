package Student;

import java.util.Scanner;

public class StudentRecordLinkedList {
	public static void menu() {
		System.out.println(" Menu ");
		System.out.println("1.Add Student");
		System.out.println("2.Delete Student");
		System.out.println("3.Update student");
		System.out.println("4.Search Student");
		System.out.println("5.Display Students");
		System.out.println("6.Exit program");
		System.out.println("Enter your choice");
	}
public static void main(String[] args) {
	StudentRecordManagement hr=new StudentRecordManagement();

	Scanner input=new Scanner(System.in);
	int option=0;
	do {
		menu();
		option=input.nextInt();
		switch(option)
		{
		case 1:
		System.out.println("Enterthe Student id Number ");
		int idNumber=input.nextInt();
		System.out.println("Enter the Student contact number");
		int contactNumber=input.nextInt();
		input.nextLine();
		System.out.println("Enter the student name");
	String name=input.nextLine();
		hr.add(new Record(name,idNumber,contactNumber));
		//System.out.println(record.toString());
		break;
		case 2:
			System.out.println("Enter Student id Number");
			int id=input.nextInt();
			hr.delete(id);
		case 3:
			System.out.println("Enter Student id number ?");
			int idNo=input.nextInt();
			hr.update(idNo, input);
			break;
		case 4:System.out.println("Enter Student id number ");
		int bookid=input.nextInt();
		if(!hr.find(bookid)) {
			System.out.println("Student id does not Exist\n");
		}
		break;
		case 5:
			hr.display();
			break;
		case 6:
			System.out.println("Existing from the program");
			System.exit(0);
		break;
		default:
			System.out.println("Invalid input");
			break;
		}
		
			
	}while(option!=0);
	
	//int IdNumber=sc.nextInt();
}
}
